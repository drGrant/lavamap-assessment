const userConfig = {
    title: "Lavamap Assessment",
  };
  
  module.exports = userConfig;
  